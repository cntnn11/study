<?php
/**
 *	@DESC CURL实例使用
*/
$url	= "http://test.study.com/curl/testlogin.php";
//curl_init();
//curl_setopt(ch, option, value);
//curl_exec();
//curl_close();


$curl	= curl_init($url);
$post_data	= array(
	'loginname'	=> 'tnn',
	'password'	=> '123456',
);
/*第二种声明初始化curl方式
curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
*/
//是否允许内容输出在页面上
//第三个参数：0时可以输出，1时不输出
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 0);

//模拟post提交
curl_setopt($curl, CURLOPT_POST, 1);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post_data));

//执行
$data	= curl_exec($curl);
//关闭
curl_close($curl);


