<?php
if(!empty($_POST))
{
	echo '<pre>';
	var_dump($_POST);
}
